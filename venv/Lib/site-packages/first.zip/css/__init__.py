
from grammar import grammar, t as css

# vim: et sw=4 sts=4
